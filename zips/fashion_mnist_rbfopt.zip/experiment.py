'''
Classification of Fashion MNIST images using a convolutional model written in Keras.
This example is using the Fashion MNIST database of clothing images provided by Zalando Research.
https://github.com/zalandoresearch/fashion-mnist

Author: IBM Watson
'''

import argparse
import gzip
import json
from keras.callbacks import TensorBoard
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras.models import Sequential
from keras.utils import to_categorical
import os
import numpy as np
import time

# By using Watson Studio's RBFOpt capability, hyperparameters are passed via config.json
print("DEBUG: loading hyperparameters")
with open("config.json", "r") as f:
    json_obj = json.load(f)
print(json_obj)

batch_size = json_obj["batch_size"]
epochs = json_obj["epochs"]
#optimizer = json_obj["optimizer"]
num_filters_1 = json_obj["num_filters_1"]
num_filters_2 = json_obj["num_filters_2"]
num_filters_3 = json_obj["num_filters_3"]
filter_size_1 = json_obj["filter_size_1"]
filter_size_2 = json_obj["filter_size_2"]
filter_size_3 = json_obj["filter_size_3"]
dropout_1 = json_obj["dropout_1"]
dropout_2 = json_obj["dropout_2"]
dropout_3 = json_obj["dropout_3"]
dropout_4 = json_obj["dropout_4"]
pool_size_1 = json_obj["pool_size_1"]
pool_size_2 = json_obj["pool_size_2"]
pool_size_3 = json_obj["pool_size_3"]
dense_neurons_1 = json_obj["dense_neurons_1"]

# Add data dir to file path
data_dir = os.environ["DATA_DIR"]
train_images_file = os.path.join(data_dir, 'train-images-idx3-ubyte.gz')
train_labels_file = os.path.join(data_dir, 'train-labels-idx1-ubyte.gz')
test_images_file = os.path.join(data_dir, 't10k-images-idx3-ubyte.gz')
test_labels_file = os.path.join(data_dir, 't10k-labels-idx1-ubyte.gz')


# Load data in MNIST format
with gzip.open(train_labels_file, 'rb') as lbpath:
    y_train = np.frombuffer(lbpath.read(), dtype=np.uint8, offset=8)

with gzip.open(train_images_file, 'rb') as imgpath:
    x_train = np.frombuffer(imgpath.read(), dtype=np.uint8, offset=16).reshape(len(y_train), 784)

with gzip.open(test_labels_file, 'rb') as lbpath:
    y_test = np.frombuffer(lbpath.read(), dtype=np.uint8, offset=8)

with gzip.open(test_images_file, 'rb') as imgpath:
    x_test = np.frombuffer(imgpath.read(), dtype=np.uint8, offset=16).reshape(len(y_test), 784)

# Split a validation set off the train set
split = int(len(y_train) * .9)-1
x_train, X_val = x_train[:split], x_train[split:]
y_train, y_val = y_train[:split], y_train[split:]

y_train = to_categorical(y_train)
y_test = to_categorical(y_test)
y_val = to_categorical(y_val)

# Reshape to correct format for conv2d input
img_rows, img_cols = 28, 28
input_shape = (img_rows, img_cols, 1)

x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
X_val = X_val.reshape(X_val.shape[0], img_rows, img_cols, 1)

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')

x_train /= 255
x_test /= 255

model = Sequential()
model.add(Conv2D(num_filters_1, kernel_size=(filter_size_1, filter_size_1),
                 activation='relu',
                 kernel_initializer='he_normal',
                 input_shape=input_shape))
model.add(MaxPooling2D((pool_size_1, pool_size_1)))
model.add(Dropout(dropout_1))
model.add(Conv2D(num_filters_2, (filter_size_2, filter_size_2), activation='relu'))
model.add(MaxPooling2D(pool_size=(pool_size_2, pool_size_2)))
model.add(Dropout(dropout_2))
model.add(Conv2D(num_filters_3, (filter_size_3, filter_size_3), activation='relu'))
model.add(MaxPooling2D(pool_size=(pool_size_3, pool_size_3)))
model.add(Dropout(dropout_3))
model.add(Flatten())
model.add(Dense(dense_neurons_1, activation='relu'))
model.add(Dropout(dropout_4))

num_classes = 10
model.add(Dense(num_classes, activation='softmax'))

model.compile(loss='categorical_crossentropy',
              #optimizer=optimizer,
              optimizer="adam",
              metrics=['accuracy'])

model.summary()

start_time = time.time()

tb_directory = os.environ["JOB_STATE_DIR"]+"/logs/tb/test"
tensorboard = TensorBoard(log_dir=tb_directory)
history = model.fit(x_train, y_train,
                    batch_size=batch_size,
                    epochs=epochs,
                    verbose=1,
                    validation_data=(X_val, y_val),
                    callbacks=[tensorboard])
score = model.evaluate(x_test, y_test, verbose=0)

end_time = time.time()
minutes, seconds = divmod(end_time-start_time, 60)
print("Total train time: {:0>2}:{:05.2f}".format(int(minutes),seconds))

print('Final train accuracy:      %.4f' % history.history['acc'][-1])
print('Final train loss: %.4f' % history.history['loss'][-1])
print('Final validation accuracy: %.4f' % history.history['val_acc'][-1])
print('Final validation loss: %.4f' % history.history['val_loss'][-1])
print('Final test accuracy:       %.4f' %  score[1])
print('Final test loss: %.4f' % score[0])

model_path = os.path.join(os.environ["RESULT_DIR"], "model.h5")
print("\nSaving model to: %s" % model_path)
model.save(model_path)

# Save the "accuracy" value to <val_dict_list.json> so the RBFOpt HPO process can evaluate the performance of the
# the training run compared to others and determine the next set of hyperparameters to explore.
training_out =[]
accuracies = history.history['val_acc']
for i in range(len(accuracies)):
    training_out.append({'epoch': i+1, 'accuracy': accuracies[i]})

with open('{}/val_dict_list.json'.format(os.environ['RESULT_DIR']), 'w') as f:
    json.dump(training_out, f)