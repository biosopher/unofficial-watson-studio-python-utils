'''
Classification of Fashion MNIST images using a convolutional model written in Keras.
This example is using the Fashion MNIST database of clothing images provided by Zalando Research.
https://github.com/zalandoresearch/fashion-mnist

Author: IBM Watson
'''

import argparse
import gzip
import json
import json
from hyperparameters import Hyperparameters
from keras.callbacks import TensorBoard
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras.models import Sequential
from keras.utils import to_categorical
import os
import numpy as np
import time


# Add data dir to file path
data_dir = os.environ["DATA_DIR"]
train_images_file = os.path.join(data_dir, 'train-images-idx3-ubyte.gz')
train_labels_file = os.path.join(data_dir, 'train-labels-idx1-ubyte.gz')
test_images_file = os.path.join(data_dir, 't10k-images-idx3-ubyte.gz')
test_labels_file = os.path.join(data_dir, 't10k-labels-idx1-ubyte.gz')

# Load data in MNIST format
with gzip.open(train_labels_file, 'rb') as lbpath:
    y_train = np.frombuffer(lbpath.read(), dtype=np.uint8, offset=8)

with gzip.open(train_images_file, 'rb') as imgpath:
    x_train = np.frombuffer(imgpath.read(), dtype=np.uint8, offset=16).reshape(len(y_train), 784)

with gzip.open(test_labels_file, 'rb') as lbpath:
    y_test = np.frombuffer(lbpath.read(), dtype=np.uint8, offset=8)

with gzip.open(test_images_file, 'rb') as imgpath:
    x_test = np.frombuffer(imgpath.read(), dtype=np.uint8, offset=16).reshape(len(y_test), 784)

# Split a validation set off the train set
split = int(len(y_train) * .9)-1
x_train, X_val = x_train[:split], x_train[split:]
y_train, y_val = y_train[:split], y_train[split:]

y_train = to_categorical(y_train)
y_test = to_categorical(y_test)
y_val = to_categorical(y_val)

# Reshape to correct format for conv2d input
img_rows, img_cols = 28, 28
input_shape = (img_rows, img_cols, 1)

x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
X_val = X_val.reshape(X_val.shape[0], img_rows, img_cols, 1)

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')

x_train /= 255
x_test /= 255

# Use hyperparameters provided by Watson Studio's HPO service
hpo_params = Hyperparameters()

model = Sequential()
model.add(Conv2D(hpo_params["num_filters_1"], kernel_size=(hpo_params["filter_size_1"], hpo_params["filter_size_1"]),
                 activation='relu',
                 kernel_initializer='he_normal',
                 input_shape=input_shape))
model.add(MaxPooling2D((hpo_params["pool_size_1"], hpo_params["pool_size_1"])))
model.add(Dropout(hpo_params["dropout_1"]))
model.add(Conv2D(hpo_params["num_filters_2"], (hpo_params["filter_size_2"], hpo_params["filter_size_2"]), activation='relu'))
model.add(MaxPooling2D(pool_size=(hpo_params["pool_size_2"], hpo_params["pool_size_2"])))
model.add(Dropout(hpo_params["dropout_2"]))
model.add(Conv2D(hpo_params["num_filters_3"], (hpo_params["filter_size_3"], hpo_params["filter_size_3"]), activation='relu'))
model.add(MaxPooling2D(pool_size=(hpo_params["pool_size_3"], hpo_params["pool_size_3"])))
model.add(Dropout(hpo_params["dropout_3"]))
model.add(Flatten())
model.add(Dense(hpo_params["dense_1"], activation='relu'))
model.add(Dropout(hpo_params["dropout_4"]))

num_classes = 10
model.add(Dense(num_classes, activation='softmax'))

model.compile(loss='categorical_crossentropy',
              #optimizer=hpo_params["optimizer"],
              optimizer="adam",
              metrics=['accuracy'])

model.summary()

start_time = time.time()

is_hpo_experiment = "SUBID" in os.environ
if is_hpo_experiment:
    print("Executing HPO training run")
    # If "SUBID" present, then we're performing HPO and need to store
    # each run separately else we'll overwrite each files results.
    # This also ensures events display properly in Watson Studio's Experiment Home.
    tb_directory = os.path.join(os.environ["LOG_DIR"], os.environ["SUBID"])
else:
    tb_directory = os.environ["LOG_DIR"]

#tb_directory = os.path.join(os.environ["LOG_DIR"], os.environ["SUBID"], "logs", "tb")
tb_directory = os.path.join(tb_directory, "logs", "tb")
tensorboard = TensorBoard(log_dir=tb_directory)

history = model.fit(x_train, y_train,
                    batch_size=hpo_params["batch_size"],
                    epochs=hpo_params["epochs"],
                    verbose=1,
                    validation_data=(X_val, y_val),
                    callbacks=[tensorboard])
score = model.evaluate(x_test, y_test, verbose=0)


if is_hpo_experiment:
    # Save the "accuracy" value to <val_dict_list.json> so the RBFOpt HPO process can evaluate the performance of the
    # the training run compared to others and determine the next set of hyperparameters to explore.
    training_out =[]
    accuracies = history.history['val_acc']
    for i in range(len(accuracies)):
        training_out.append({'epoch': i+1, 'accuracy': accuracies[i]})

    with open('{}/val_dict_list.json'.format(os.environ['RESULT_DIR']), 'w') as f:
        json.dump(training_out, f)

end_time = time.time()
minutes, seconds = divmod(end_time-start_time, 60)
print("Total train time: {:0>2}:{:05.2f}".format(int(minutes),seconds))

model_path = os.path.join(os.environ["RESULT_DIR"], "model.h5")
print("\nSaving model to: %s" % model_path)
model.save(model_path)

print('Final train accuracy:      %.4f' % history.history['acc'][-1])
print('Final train loss: %.4f' % history.history['loss'][-1])
print('Final validation accuracy: %.4f' % history.history['val_acc'][-1])
print('Final validation loss: %.4f' % history.history['val_loss'][-1])
print('Final test accuracy:       %.4f' %  score[1])
print('Final test loss: %.4f' % score[0])
