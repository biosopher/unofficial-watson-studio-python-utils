'''
Classification of Fashion MNIST images using a convolutional network in PyTorch.
This example is using the Fashion MNIST database of clothing images
provided by Zalando Research: https://github.com/zalandoresearch/fashion-mnist

Author: IBM Watson
'''

import json
import os
import time
import sys

from emetrics import EMetrics
from fashion_mnist_data import FashionMnistData
from hyperparameters import Hyperparameters
from tensorboardX import SummaryWriter # Install using "pip install tensorboardX"
from torchsummary import model_summary

import torch
from torch.autograd import Variable
import torch.backends.cudnn as cudnn
import torchvision.datasets as dsets
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms

start_time = time.time()

# Load Hyperparameters
hparams = Hyperparameters()

# Prepare dataset
batch_size = hparams["batch_size"]
num_epochs = hparams["epochs"]

fashion_mnist_data = FashionMnistData(batch_size)
train_loader = fashion_mnist_data.get_train_data_loader()
test_loader = fashion_mnist_data.get_test_data_loader()

# https://stackoverflow.com/questions/45584907/flatten-layer-of-pytorch-build-by-sequential-container
class __Flatten(nn.Module):
    def forward(self, x):
        return x.view(x.size()[0], -1)

# Create the neural network
class CNNModel(nn.Module):

    def __init__(self):
        super(CNNModel, self).__init__()

        self.layer1 = nn.Sequential(nn.Conv2d(in_channels=1, out_channels=hparams["num_filters_1"],
                                              kernel_size=hparams["filter_size_1"], stride=1, padding=0),
                                    nn.BatchNorm2d(hparams["num_filters_1"]),
                                    nn.ReLU(),
                                    nn.MaxPool2d(kernel_size=hparams["pool_size_1"]),
                                    nn.Dropout(p=hparams["dropout_1"]))

        self.layer2 = nn.Sequential(nn.Conv2d(in_channels=hparams["num_filters_1"], out_channels=hparams["num_filters_2"],
                                              kernel_size=hparams["filter_size_2"], stride=1, padding=0),
                                    nn.BatchNorm2d(hparams["num_filters_2"]),
                                    nn.ReLU(),
                                    nn.MaxPool2d(kernel_size=hparams["pool_size_2"]),
                                    nn.Dropout(p=hparams["dropout_2"]))


        self.layer3 = nn.Sequential(nn.Conv2d(in_channels=hparams["num_filters_2"], out_channels=hparams["num_filters_3"],
                                              kernel_size=hparams["filter_size_3"], stride=1, padding=0),
                                    nn.BatchNorm2d(hparams["num_filters_3"]),
                                    nn.ReLU(),
                                    nn.MaxPool2d(kernel_size=hparams["pool_size_3"]),
                                    nn.Dropout(p=hparams["dropout_3"]))


        # We flatten before passing into a fully-connected layer so much now calculate the fully flattened in_size
        # NOTE: that the flattening happens via out.view(out.size(0), -1) in the forward pass (see below)
        image_size = 28
        cnn1_out = self.get_output_size(image_size, hparams["filter_size_1"], 1, 0)
        maxp1_out = self.get_output_size(cnn1_out, hparams["pool_size_1"], hparams["pool_size_1"], 0)
        cnn2_out = self.get_output_size(maxp1_out, hparams["filter_size_2"], 1, 0)
        maxp2_out = self.get_output_size(cnn2_out, hparams["pool_size_2"], hparams["pool_size_2"], 0)
        cnn3_out = self.get_output_size(maxp2_out, hparams["filter_size_3"], 1, 0)
        maxp3_out = self.get_output_size(cnn3_out, hparams["pool_size_3"], hparams["pool_size_3"], 0)
        flattened_size = hparams["num_filters_3"] * maxp3_out * maxp3_out

        self.fc1 = nn.Linear(flattened_size, hparams["dense_1"])
        self.dropout4 = nn.Dropout(p=hparams["dropout_4"])

        # Fully connected 2 (readout)
        self.fc2 = nn.Linear(hparams["dense_1"], 10)

    def get_output_size(self, input_size, filter_size, stride, padding):
        return int(( input_size - filter_size + 2 * padding ) / stride + 1)

    def forward(self, x):
        # Convolution 1
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)

        # Flatten
        # Original size: (a, b, c, d)
        # New out size: (a, b*c*d)
        out = out.view(out.size(0), -1)
        out = self.fc1(out)
        out = self.dropout4(out)

        # Linear function (readout)
        out = self.fc2(out)

        return out

# Instantiate our classes
model = CNNModel()

#Define the optimizer and loss function
learning_rate = 0.001
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=0.0001)
loss_fn = nn.CrossEntropyLoss()

# Setup GPUs
use_cuda = torch.cuda.is_available()
if use_cuda: # GPU
    model.cuda()
    model = torch.nn.DataParallel(model, device_ids=range(torch.cuda.device_count()))
    cudnn.benchmark = True
    loss_fn = loss_fn.cuda()
    model_path = os.path.join(os.environ["RESULT_DIR"], "checkpoint.pth.tar")
    tb_directory = os.path.join(os.environ["LOG_DIR"], "logs", "tb")
else: # CPU
    model_path = os.path.join("results", "checkpoint.pth.tar")
    tb_directory = "logs"

# Write summary of model's hyperparameters
channels = 1
image_height = image_width = 28
model_summary(model, input_size=(channels, image_height, image_width))

# Log to TensorBoard using TensorBoard X
tb_writer = SummaryWriter(tb_directory)

# Log metrics to Studio's Experiment Assistant
is_hpo_experiment = "SUBID" in os.environ
if is_hpo_experiment:
    print("Executing HPO training run")
    # If "SUBID" present, then we're performing HPO and need to store
    # each run separately else we'll overwrite each files results.
    # This also ensures events display properly in Watson Studio's Experiment Home.
    em = EMetrics.open(os.environ["SUBID"])
    hpo_test_accuracies = []
else:
    em = EMetrics.open()

# Train the model
iter = 0
for epoch in range(num_epochs):
    # Print Loss
    print('epoch: {}'.format(epoch+1))
    for i, (inputs, targets) in enumerate(train_loader):

        if use_cuda:
            inputs, targets = inputs.cuda(), targets.cuda()
        inputs = Variable(inputs)
        targets = Variable(targets)

        # Clear gradients w.r.t. parameters
        optimizer.zero_grad()

        # Forward pass to get output/logits
        outputs = model(inputs)

        # Calculate Loss: softmax --> cross entropy loss
        loss = loss_fn(outputs, targets)

        # Getting gradients w.r.t. parameters
        loss.backward()

        # Updating parameters
        optimizer.step()

        iter += 1
        if iter % 100 == 0:
            # Calculate Accuracy
            correct = 0
            total = 0
            # Iterate through test dataset
            for inputs, targets in test_loader:

                if use_cuda:
                    inputs, targets = inputs.cuda(), targets.cuda()
                inputs = Variable(inputs)

                outputs = model(inputs) # Forward pass only to get logits/output

                # Get predictions from the maximum value
                _, predicted = torch.max(outputs.data, 1)

                # Total number of targets
                total += targets.size(0)

                correct += (predicted == targets).sum()

            accuracy = 100 * correct / total

            print('Iteration: {}. Loss: {}. Accuracy: {}'.format(iter, loss.item(), accuracy.item()))

            # Log metrics to TensorBoard
            tb_writer.add_scalar("test_loss", loss.item(), iter)
            tb_writer.add_scalar("test_accuracy", accuracy.item(), iter)

            em.record("train", epoch, {'test_loss': loss.item(), 'test_acc': accuracy.item()})

            if is_hpo_experiment:
                # Save the "accuracy" value to <val_dict_list.json> so the RBFOpt HPO process can evaluate performance
                # of this run compared to others and determine the next set of hyperparameters to explore.
                hpo_test_accuracies.append({'epoch': i+1, 'accuracy': accuracy.item()})

# Close Studio's Emetrics
em.close()

if is_hpo_experiment:
    with open('{}/val_dict_list.json'.format(os.environ['RESULT_DIR']), 'w') as f:
        json.dump(hpo_test_accuracies, f)

print("\nSaving model to: %s" % model_path)
torch.save({'epoch': epoch + 1,
            'arch': hparams,
            'model': model.module if use_cuda else model,
            'state_dict': model.state_dict(),
            'optimizer' : optimizer.state_dict()},
             model_path)

end_time = time.time()
minutes, seconds = divmod(end_time-start_time, 60)
print("Total train time: {:0>2}:{:05.2f}".format(int(minutes), seconds))