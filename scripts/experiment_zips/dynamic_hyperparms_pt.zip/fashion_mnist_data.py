import gzip
import numpy as np
import os
import torch

class FashionMnistData:

    def __init__(self, batch_size):

        self.load_datasets(batch_size)

    def load_datasets(self, batch_size):

        use_cuda = torch.cuda.is_available()
        if use_cuda:
            # Running in the Cloud
            data_dir = os.environ["DATA_DIR"]
            num_workers=1
            pin_memory=True
        else:
            # Running Locally
            data_dir = "data"
            num_workers=5
            pin_memory=False

        # Add data dir to file path
        train_images_file = os.path.join(data_dir, 'train-images-idx3-ubyte.gz')
        train_labels_file = os.path.join(data_dir, 'train-labels-idx1-ubyte.gz')
        test_images_file = os.path.join(data_dir, 't10k-images-idx3-ubyte.gz')
        test_labels_file = os.path.join(data_dir, 't10k-labels-idx1-ubyte.gz')


        # Load data in MNIST format
        with gzip.open(train_labels_file, 'rb') as lbpath:
            y_train = np.frombuffer(lbpath.read(), dtype=np.uint8,
                                   offset=8)

        with gzip.open(train_images_file, 'rb') as imgpath:
            X_train = np.frombuffer(imgpath.read(), dtype=np.uint8,
                                   offset=16).reshape(len(y_train), 784)

        with gzip.open(test_labels_file, 'rb') as lbpath:
            y_test = np.frombuffer(lbpath.read(), dtype=np.uint8,
                                   offset=8)

        with gzip.open(test_images_file, 'rb') as imgpath:
            X_test = np.frombuffer(imgpath.read(), dtype=np.uint8,
                                   offset=16).reshape(len(y_test), 784)


        # Reshape (60000, 784) to (60000, 28, 28)  for conv2d input
        img_rows, img_cols = 28, 28
        X_train = X_train.reshape(X_train.shape[0], img_rows, img_cols)
        X_test = X_test.reshape(X_test.shape[0], img_rows, img_cols)

        # Reshape (60000, 28, 28) to (60000, 28, 28, 1)
        X_train = np.expand_dims(X_train, axis=1).astype('float32')
        X_test = np.expand_dims(X_test, axis=1).astype('float32')

        # normalize
        X_train /= 255.0
        X_test /= 255.0

        # Transform to Torch tensors
        X_train = torch.from_numpy(X_train)
        X_test = torch.from_numpy(X_test)

        y_train = torch.LongTensor(y_train)
        y_test = torch.LongTensor(y_test)

        # create custom dataloaders
        train_dataset = torch.utils.data.TensorDataset(X_train, y_train)
        test_dataset = torch.utils.data.TensorDataset(X_test, y_test)

        # If using CPU, increase num_workers and set pin_memory to False
        self.train_loader = torch.utils.data.DataLoader(train_dataset,
                                                        batch_size=batch_size,
                                                        shuffle=True,
                                                        num_workers=num_workers,
                                                        pin_memory=pin_memory)

        self.test_loader = torch.utils.data.DataLoader(test_dataset,
                                                       batch_size=batch_size,
                                                       shuffle=True,
                                                        num_workers=num_workers,
                                                        pin_memory=pin_memory)

    def get_train_data_loader(self):
        return self.train_loader

    def get_test_data_loader(self):
        return self.test_loader
