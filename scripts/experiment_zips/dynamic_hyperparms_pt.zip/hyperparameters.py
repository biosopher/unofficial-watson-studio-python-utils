import argparse
import json
import os
import sys

HYPERPARAMS_CONFIG_FILE = "config.json"

class Hyperparameters(dict):

    def __init__(self):

        if os.path.isfile(HYPERPARAMS_CONFIG_FILE):

            print("Loading hyperparameters from {}".format(HYPERPARAMS_CONFIG_FILE))
            with open(HYPERPARAMS_CONFIG_FILE, "r") as f:
                json_obj = json.load(f)

            for key in json_obj:
                self.convert_value_for_key(key, json_obj[key])

        print("Found {} hyperparameters".format(len(self)))

    def convert_value_for_key(self, key, value):

        try:
            if float(value) == int(value):
                print("int: %s = %s" % (key, value))
                self.update({key : int(value)})
            else:
                print("float: %s = %s" % (key, float(value)))
                self.update({key : float(value)})
        except ValueError:
            try:
                print("float: %s = %s" % (key, float(value)))
                self.update({key : float(value)})
            except ValueError:
                print("str: %s = %s" % (key, value))
                self.update({key : value})
